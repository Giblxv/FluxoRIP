(() => {
  'use strict';
  const root = document.documentElement;
  const motionButton = document.querySelector('.motion-toggle');
  const preferenceKey = 'fluxorip.landing.motion';
  let preference = null;
  let release = null;
  let tiltFrame = 0;
  try { preference = localStorage.getItem(preferenceKey); } catch (_) { /* Storage can be unavailable. */ }

  function syncMotion() {
    // Motion is an explicit product preference; only the manual switch pauses it.
    const enabled = preference !== 'off';
    root.dataset.motion = enabled ? 'on' : 'off';
    root.classList.toggle('js-motion', enabled);
    motionButton.setAttribute('aria-pressed', String(enabled));
    motionButton.setAttribute('aria-label', enabled ? 'Pausar animações' : 'Ativar animações');
    motionButton.title = motionButton.getAttribute('aria-label');
    motionButton.querySelector('[data-motion-label]').textContent = enabled ? 'on' : 'off';
    if (!enabled) resetTilt();
  }
  motionButton.addEventListener('click', () => {
    preference = root.dataset.motion === 'on' ? 'off' : 'on';
    try { localStorage.setItem(preferenceKey, preference); } catch (_) { /* Keep a session preference. */ }
    syncMotion();
  });
  window.addEventListener('storage', event => {
    if (event.key === preferenceKey || event.key === null) {
      try { preference = localStorage.getItem(preferenceKey); } catch (_) { return; }
      syncMotion();
    }
  });

  const art = document.querySelector('.hero-art');
  function resetTilt() {
    cancelAnimationFrame(tiltFrame);
    if (art) {
      art.style.removeProperty('--tilt-x');
      art.style.removeProperty('--tilt-y');
    }
  }
  art.addEventListener('pointermove', event => {
    if (root.dataset.motion !== 'on' || event.pointerType !== 'mouse') return;
    cancelAnimationFrame(tiltFrame);
    tiltFrame = requestAnimationFrame(() => {
      const rect = art.getBoundingClientRect();
      art.style.setProperty('--tilt-x', ((.5 - (event.clientY - rect.top) / rect.height) * 5).toFixed(2) + 'deg');
      art.style.setProperty('--tilt-y', (((event.clientX - rect.left) / rect.width - .5) * 5).toFixed(2) + 'deg');
    });
  });
  art.addEventListener('pointerleave', resetTilt);
  syncMotion();

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: .07, rootMargin: '0px 0px -15px 0px' });
    document.querySelectorAll('.reveal').forEach(element => observer.observe(element));
  } else document.querySelectorAll('.reveal').forEach(element => element.classList.add('is-visible'));

  const header = document.querySelector('.site-header');
  let scrollQueued = false;
  window.addEventListener('scroll', () => {
    if (scrollQueued) return;
    scrollQueued = true;
    requestAnimationFrame(() => { header.classList.toggle('is-scrolled', window.scrollY > 8); scrollQueued = false; });
  }, { passive: true });

  const menuButton = document.querySelector('.menu-toggle');
  const menu = document.querySelector('#mobile-nav');
  function closeMenu(returnFocus = false) {
    menu.hidden = true;
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Abrir menu');
    menuButton.querySelector('use').setAttribute('href', '#i-menu');
    if (returnFocus) menuButton.focus();
  }
  menuButton.addEventListener('click', () => {
    if (!menu.hidden) return closeMenu();
    menu.hidden = false;
    menuButton.setAttribute('aria-expanded', 'true');
    menuButton.setAttribute('aria-label', 'Fechar menu');
    menuButton.querySelector('use').setAttribute('href', '#i-close');
  });
  menu.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !menu.hidden) closeMenu(true); });
  window.matchMedia('(min-width: 741px)').addEventListener('change', event => { if (event.matches) closeMenu(); });

  const tabs = [...document.querySelectorAll('[data-tab]')];
  function selectTab(tab, focus = false) {
    tabs.forEach(item => {
      const selected = item === tab;
      item.setAttribute('aria-selected', String(selected));
      item.tabIndex = selected ? 0 : -1;
      const panel = document.getElementById(item.getAttribute('aria-controls'));
      panel.hidden = !selected;
      panel.classList.toggle('is-entering', selected);
    });
    if (focus) tab.focus();
  }
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectTab(tab));
    tab.addEventListener('keydown', event => {
      let next;
      if (event.key === 'ArrowRight' || event.key === 'ArrowDown') next = (index + 1) % tabs.length;
      if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') next = (index + tabs.length - 1) % tabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = tabs.length - 1;
      if (next !== undefined) { event.preventDefault(); selectTab(tabs[next], true); }
    });
  });
  const mobileTabs = window.matchMedia('(max-width: 960px)');
  function syncTabsOrientation() { document.querySelector('[role=tablist]').setAttribute('aria-orientation', mobileTabs.matches ? 'horizontal' : 'vertical'); }
  mobileTabs.addEventListener('change', syncTabsOrientation);
  syncTabsOrientation();

  const download = document.querySelector('[data-download]');
  const releaseStatus = document.querySelector('#release-status');
  const hashButton = document.querySelector('[data-copy-hash]');
  const checksumLink = document.querySelector('[data-checksum-link]');
  download.addEventListener('click', event => { if (download.getAttribute('aria-disabled') === 'true') event.preventDefault(); });

  function localDownloadPath(path, extension) {
    if (typeof path !== 'string' || !/^downloads\/[A-Za-z0-9._-]+$/.test(path) || !path.endsWith(extension)) throw new Error('Invalid download path');
    const url = new URL(path, document.baseURI);
    if (url.origin !== location.origin) throw new Error('External download');
    return url;
  }
  async function loadRelease() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch('release.json', { signal: controller.signal, cache: 'no-cache', credentials: 'omit', redirect: 'error' });
      if (!response.ok) throw new Error('Missing release');
      const candidate = await response.json();
      if (!candidate || !/^\d+\.\d+\.\d+$/.test(candidate.version) || !/^[a-f0-9]{64}$/.test(candidate.sha256)
          || !Number.isSafeInteger(candidate.sizeBytes) || candidate.sizeBytes <= 0 || candidate.sizeBytes > 1024 ** 3
          || candidate.nativeWindowsValidated !== false || candidate.signed !== false) throw new Error('Invalid release');
      const url = localDownloadPath(candidate.url, '.exe');
      if (candidate.filename !== url.pathname.split('/').pop()) throw new Error('Mismatched filename');
      const head = await fetch(url, { method: 'HEAD', signal: controller.signal, cache: 'no-cache', credentials: 'omit', redirect: 'error' });
      if (!head.ok) throw new Error('Missing installer');
      const contentType = head.headers.get('content-type') || '';
      const length = head.headers.get('content-length');
      if (contentType.includes('text/html') || (length !== null && Number(length) !== candidate.sizeBytes)) throw new Error('Wrong installer');
      release = candidate;
      document.querySelectorAll('[data-version]').forEach(element => { element.textContent = release.version; });
      document.querySelectorAll('[data-file-size]').forEach(element => { element.textContent = (release.sizeBytes / 1024 ** 2).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' MiB'; });
      download.href = url.href;
      download.download = release.filename;
      download.setAttribute('aria-disabled', 'false');
      download.querySelector('span').textContent = 'Baixar Fluxo RIP';
      releaseStatus.textContent = 'Instalador para Windows x64 · Download direto';
      document.querySelector('[data-checksum]').textContent = release.sha256;
      hashButton.disabled = false;
      if (release.checksumUrl) {
        try { checksumLink.href = localDownloadPath(release.checksumUrl, '.txt').href; checksumLink.download = 'SHA256SUMS.txt'; checksumLink.hidden = false; } catch (_) { /* Optional link. */ }
      }
    } catch (_) {
      download.removeAttribute('href');
      download.setAttribute('aria-disabled', 'true');
      download.classList.add('unavailable');
      download.querySelector('span').textContent = 'Download indisponível';
      releaseStatus.textContent = 'O pacote não está disponível agora. Tente recarregar a página mais tarde.';
    } finally { clearTimeout(timer); }
  }
  hashButton.addEventListener('click', async () => {
    if (!release) return;
    const feedback = document.querySelector('.copy-result');
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(release.sha256);
      feedback.textContent = 'Código copiado.';
    } catch (_) {
      const code = document.querySelector('[data-checksum]');
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(code);
      selection.removeAllRanges(); selection.addRange(range);
      feedback.textContent = 'Código selecionado. Use Ctrl+C ou a opção Copiar do seu dispositivo.';
    }
  });
  loadRelease();
})();
