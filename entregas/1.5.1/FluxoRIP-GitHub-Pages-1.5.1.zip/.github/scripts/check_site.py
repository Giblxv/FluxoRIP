"""Validate the public site before GitHub Pages deployment; standard library only."""
import hashlib
import json
from pathlib import Path
import re
import sys


def validate(root: Path) -> dict:
    if not root.is_dir():
        raise ValueError('Pasta public/ ausente.')
    for name in ('index.html', 'styles.css', 'script.js', 'release.json', '.nojekyll'):
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Arquivo público obrigatório ausente: {name}')
    release = json.loads((root / 'release.json').read_text(encoding='utf-8'))
    if not isinstance(release, dict):
        raise ValueError('Manifesto público inválido.')
    name = release.get('filename')
    version = release.get('version')
    digest = release.get('sha256')
    size = release.get('sizeBytes')
    if (not isinstance(version, str) or not re.fullmatch(r'\d+\.\d+\.\d+', version)
            or not isinstance(name, str)
            or name not in {f'FluxoRIP-{version}-Instalador-Windows-x64.exe',
                            f'FluxoRIP-{version}-Windows-x64-Setup.exe'}
            or release.get('url') != f'downloads/{name}'
            or not isinstance(digest, str) or not re.fullmatch(r'[a-f0-9]{64}', digest)
            or type(size) is not int or size <= 0):
        raise ValueError('Nome, caminho, tamanho ou SHA256 inválido no manifesto.')
    if release.get('nativeWindowsValidated') is not False or release.get('signed') is not False:
        raise ValueError('Atualize os avisos da página antes de alterar o estado da validação/assinatura.')
    checksum_url = 'downloads/SHA256SUMS.txt'
    if release.get('checksumUrl') != checksum_url:
        raise ValueError('Caminho de verificação inválido.')
    download_files = {name, 'SHA256SUMS.txt'}
    if 'guideUrl' in release:
        if release['guideUrl'] != 'downloads/LEIA-ME.txt':
            raise ValueError('Caminho do guia inválido.')
        download_files.add('LEIA-ME.txt')
    root_files = {'index.html', 'styles.css', 'script.js', 'release.json', '.nojekyll'}
    asset_types = {'.svg', '.png', '.jpg', '.jpeg', '.webp', '.avif', '.gif', '.ico',
                   '.woff', '.woff2', '.ttf', '.otf', '.css', '.txt'}
    for path in root.rglob('*'):
        relative = path.relative_to(root)
        if path.is_symlink():
            raise ValueError('Links simbólicos não são permitidos no site público.')
        if not path.is_file():
            continue
        allowed = (
            len(relative.parts) == 1 and relative.name in root_files
            or relative.parts[0] == 'assets' and path.suffix.lower() in asset_types
               and not any(part.startswith('.') for part in relative.parts)
            or len(relative.parts) == 2 and relative.parts[0] == 'downloads'
               and relative.name in download_files
        )
        if not allowed:
            raise ValueError(f'Arquivo fora da lista pública: {relative}')
    for name in download_files:
        if not (root / 'downloads' / name).is_file():
            raise ValueError(f'Download obrigatório ausente: {name}')
    installer = root / release['url']
    actual = hashlib.sha256()
    with installer.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            actual.update(block)
    if installer.stat().st_size != size or actual.hexdigest() != digest:
        raise ValueError('O instalador não corresponde ao tamanho/SHA256 do manifesto.')
    if (root / checksum_url).read_text(encoding='utf-8').strip() != f'{digest}  {release["filename"]}':
        raise ValueError('O arquivo SHA256SUMS.txt não corresponde ao manifesto.')
    if '@@DOWNLOAD_URL@@' in (root / 'index.html').read_text(encoding='utf-8'):
        raise ValueError('O HTML contém um link de download não preparado.')
    print(f'Site verificado. Instalador: {release["filename"]}; SHA256: {digest}')
    return release


if __name__ == '__main__':
    try:
        validate(Path(sys.argv[1] if len(sys.argv) > 1 else 'public'))
    except (OSError, ValueError) as error:
        print(f'ERRO: {error}', file=sys.stderr)
        raise SystemExit(1)
