# Fluxo RIP — página de download

Este repositório contém somente a página pública e o instalador Windows do Fluxo
RIP. A pasta `public/` é publicada no GitHub Pages. O workflow verifica o site e o
SHA256 do instalador antes da publicação.

## Publicar pela primeira vez

1. No GitHub, crie um repositório **público** separado, por exemplo
   `fluxorip-site`. Marque **Add a README file** para criar a branch `main`.
2. Nesse repositório, abra **Settings → Pages**. Em **Build and deployment →
   Source**, selecione **GitHub Actions**. Faça isso antes de enviar o pacote.
3. Instale e abra o **GitHub Desktop**, entre na sua conta e use **File → Clone
   repository** para clonar esse novo repositório no computador.
4. Extraia o ZIP preparado para GitHub Pages. Copie **todo o conteúdo extraído**
   para a raiz do repositório clonado, inclusive `.github/`, `public/`,
   `.gitignore` e este `README.md`. Você pode substituir o README inicial do
   repositório novo. Não crie outra pasta envolvendo esses arquivos.
5. No GitHub Desktop, confira os arquivos, escreva uma descrição como
   `Publicar página do Fluxo RIP`, clique em **Commit to main** e depois em
   **Push origin**.
6. No GitHub, abra a aba **Actions** e acompanhe **Publicar site Fluxo RIP**.
   Espere as etapas `build` e `deploy` terminarem com sucesso.
7. Volte a **Settings → Pages** e abra o endereço informado pelo GitHub. Para o
   exemplo `Giblxv/fluxorip-site`, o endereço esperado é
   `https://giblxv.github.io/fluxorip-site/`. Este é um exemplo; o pacote local
   não significa que o site já foi publicado.

O instalador tem aproximadamente **29 MB**, acima do limite de **25 MiB por
arquivo** no envio pelo navegador do GitHub. Use **GitHub Desktop ou Git** para
enviar a pasta extraída. O arquivo está abaixo do limite de 100 MiB por arquivo
do GitHub. Enviar o ZIP como um único arquivo não publica a página.

Se `.github/` não aparecer, habilite a exibição de arquivos ocultos. O caminho
do workflow deve ser exatamente `.github/workflows/deploy-pages.yml`, na raiz
do repositório.

## O que deve existir no repositório

```text
.github/
  scripts/check_site.py
  workflows/deploy-pages.yml
.gitignore
README.md
public/
  .nojekyll
  index.html
  styles.css
  script.js
  release.json
  assets/
  downloads/
```

Somente `public/` vai para o site. Preserve os nomes e a organização dos
arquivos; os links relativos também funcionam no endereço com o nome do
repositório. Não coloque um `CNAME` sem configurar antes um domínio próprio.

Não envie a pasta de dados `FORGE`, banco, credenciais ou a API da gráfica para
este repositório. O pacote preparado já separa o conteúdo público do aplicativo.

## Atualizar a página

Substitua a pasta `public/` pela do novo pacote preparado, em vez de misturar as
duas pastas e deixar instaladores antigos. Se personalizou o site, preserve antes
uma cópia dessas alterações. Atualize também os arquivos de `.github/` quando
vierem no pacote. Confira no GitHub Desktop os arquivos alterados e removidos,
faça o commit e use **Push origin**. O workflow publica novamente após validar
a integridade.

O workflow também pode ser iniciado em **Actions → Publicar site Fluxo RIP →
Run workflow**, na branch `main`.

## Se não publicar

- **Não aparece a opção Pages:** confira se o repositório é público e se a sua
  conta pode administrá-lo.
- **O workflow não aparece:** confira o caminho de `.github/`, a branch `main`
  e se o repositório permite GitHub Actions em **Settings → Actions → General**.
- **A verificação falhou:** abra o log da etapa de integridade. Não edite o
  SHA256 para esconder uma divergência; use novamente o pacote correto.
- **O deploy falhou:** confira se a origem do Pages está em **GitHub Actions**.
  Restrições do ambiente `github-pages` também podem exigir uma aprovação na
  interface do GitHub.
- **Página com 404:** use o endereço mostrado em **Settings → Pages** e aguarde
  a execução terminar. Não altere os caminhos dos arquivos para tentar corrigir.
- **Download indisponível:** confirme que `public/release.json` e o instalador
  em `public/downloads/` foram enviados juntos.

## Sobre a versão disponível

A página identifica o programa como versão de avaliação. O instalador foi
compilado e testado sob Wine, ainda sem assinatura digital e sem validação
nativa Windows 10/11 comprovada nesta entrega. A fila é administrativa; o
programa não envia comandos físicos de impressão ou limpeza nem aplica
firmware à controladora. Essas informações permanecem visíveis na página.
